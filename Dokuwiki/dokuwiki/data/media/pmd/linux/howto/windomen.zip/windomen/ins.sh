#!/bin/bash

#создание резервных копий файлов конфигурации
cp -i \
/etc/hosts \
/etc/avahi/avahi-daemon.conf \
/etc/krb5.conf \
/etc/samba/smb.conf \
/etc/nsswitch.conf \
/etc/security/limits.conf \
/etc/pam.d/common-session \
backup

#копирование настроенных файлов
#cp -i hosts /etc/hosts
cp -i avahi-daemon.conf /etc/avahi/avahi-daemon.conf
cp -i krb5.conf /etc/krb5.conf
cp -i smb.conf /etc/samba/smb.conf
cp -i nsswitch.conf /etc/nsswitch.conf
cp -i limits.conf /etc/security/limits.conf
cp -i common-session /etc/pam.d/common-session
