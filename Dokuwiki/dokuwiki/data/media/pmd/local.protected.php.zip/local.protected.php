<?php
date_default_timezone_set("Europe/Kiev");
